const app = require("./src/app");

app.listen(4000, () => console.log('Now browse to localhost:4000/graphql'));